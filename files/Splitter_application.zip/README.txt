SPLITTER
Simulating the Breaking of Glass in Real Time
a modelling project at Link�ping University

Authors:
Jesper Carlson, jesca144@student.liu.se
Daniel Enetoft, danen736@student.liu.se
Anders Fjeldstad, andfj645@student.liu.se
Kristofer G�rdeborg, kriga592@student.liu.se


License:
Splitter is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

For more information, see Copyright.txt.


Description:
Splitter is a modelling project aiming to simulate the breaking of window glass
as realistically as possible while still executing in real time. This program
demonstrates the result. For more information, please refer to the project
report.


System requirements:
The simulation has not been tested on that many machines, but we have found it
working excellently on a PC with the following hardware:

AMD 64 3500+ or equivalent
32 Mb of working memory (RAM)
Nvidia GeForce 6800GT or equivalent
9 Mb of free harddrive space
Microsoft Windows with OpenGL installed

The program will probably run quite smoothly even if the machine is not as
powerful as the one above, but lesser "lags" could occur. Generally,
an OpenGL-enabled graphics card is highly recommended. The source code should
compile under other operating systems as well, possibly with some modifications
needed. For this, OpenGL, GLU and GLFW are all required.


Installation:
Uncompress all files to an empty directory. Make sure the TEXTURES-folder
is included.


How to use the simulation:
Start the program by double-clicking on the executable file. The program will
run in full-screen mode and the resolution will default to 1024*768. If you
want to change the resolution manually, simply supply two extra arguments at
the command line when you execute the program. For example, to set the
resolution to 1600*1200, use the following command:

	splitter.exe 1600 1200

Once the program is running, use the mouse to look around in the virtual
environment. It is possible to move around and control the simulation using
the following keys:

	W or UP-arrow		Move forward
	S or DOWN-arrow		Move backward
	A or LEFT-arrow		Move left
	D or RIGHT-arrow	Move right
	Keypad +			Increase impact velocity
	Keypad -			Decrease impact velocity
	Left mouse button	Hit the glass window where the crosshair points
	Right mouse button	Remove loose glass pieces from an existing crack pattern
	SPACE				Reset the simulation
	ESCAPE				Quit the program
